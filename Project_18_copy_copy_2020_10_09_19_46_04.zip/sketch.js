var PLAY = 1; 
var END = 0; 
var gameState = PLAY;

var monkey, monkeyRunning, ground, score, restart, gameover, monkeyCollided, groundImage, groundCollided;

var ObstaclesGroup, obstacle;

var BananaGroup, banana1; 

var score;

function preload() {
  
  monkeyRunning = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png","Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  
  groundImage= loadImage("jungle.jpg");
  
  obstacle = loadImage("stone.png");
  
  banana1 = loadImage("banana.png");

}

function setup(){
 
  
  
  createCanvas(600, 600);
 ground = createSprite(400,300,600,10);
 ground.addImage("ground", groundImage);
 ground.x = ground.width/2;
 ground.velocityX = -8;
 
 monkey = createSprite(100,485,10,10); 
 monkey.addAnimation("running", monkeyRunning);
 monkey.scale = 0.1;
 
  groundCollided = createSprite(300,520,600,10);
  groundCollided.visible = false; 
  
  ObstaclesGroup = new Group(); 
  
  BananaGroup = new Group();
  
  score = 0;
}

function draw(){
  background(0);
  
  

  
  
  monkey.debug = true;
  
  if(gameState === PLAY){

    
     if(keyDown("space") && monkey.y>450){
     monkey.velocityY = -15;
  }
  monkey.velocityY = monkey.velocityY + 0.8;
     
      if(ground.x<100){
     ground.x = ground.width/2;
  }
    
    
    
      if(ObstaclesGroup.isTouching(monkey)){
     ObstaclesGroup.destroyEach();
        score = score -1;
        
  }
   }
  
  obstacles();
  
  banana();  
  

  if(BananaGroup.isTouching(monkey)){
    
    
    BananaGroup.destroyEach();
    score = score + 1;
     
  }
 
  
  monkey.collide(groundCollided); 
  

  drawSprites();
  
  fill("red");
  textSize(15);
  textFont("Courier New"); 
  textStyle(BOLD);
    text("Score: " + score, 500, 150);
}

function obstacles(){
  if(frameCount % 80 === 0){
     var stone = createSprite(600,485,10,485);
    stone.velocityX = -9;
    stone.addImage(obstacle);
    stone.scale = 0.2;
    ObstaclesGroup.add(stone);
  }
}

function banana(){
if(frameCount % 80 === 0){ 
   var banana = createSprite(600,360,10,10); 
   banana.velocityX = -9;
   banana.addImage(banana1);
  banana.scale = 0.1;
  BananaGroup.add(banana);
  banana.debug = true;
  
}
}